<style>
    .cm-upgrade-table {
        border-collapse: collapse;
    }

    .cm-upgrade-table td {
        padding: 6px;
    }

    .cm-upgrade-table .tr-head td {
        position: relative;
    }

    .cm-upgrade-table .tr-head td .dashicons {
        position: relative;
        top: 5px;
    }

    .cm-upgrade-table tr:not(.tr-head) td:first-child {
        text-align: left;
        padding: 6px 40px;
    }

    div.cminds_ads_wrapper_white {
        display: inline-block;
        padding: 1em;
        background: #fff;
        border: solid 1px #E0E0E0;
        margin: 10px 0 10px 0;
        vertical-align: top;
    }

    .cminds_ads_wrapper_white a {
        text-decoration: none;
    }

    .cminds_ads_wrapper_white a[href*="cm-wordpress-plugins-yearly-membership"]:before {
        content: "" !important;
    }

    .ui-widget-shadow {
        opacity: 1 !important;
    }
    .ui-widget-shadow {
        background: #fff !important;
    }

</style>
<div class="cminds_ads_wrapper_white">
    <a href="https://www.cminds.com/wordpress-plugins-library/seo-keyword-hound-wordpress/" target="_blank">
        <img src="<?php echo plugin_dir_url( __FILE__ ); ?>keywordhoundbanner1.png">
    </a>
    <span style="margin-left:20px;">
        <a href="https://www.cminds.com/wordpress-plugins-library/cm-wordpress-plugins-yearly-membership/"
           target="_blank">
            <img src="<?php echo plugin_dir_url( __FILE__ ); ?>99suite.png">
        </a>
    </span>
</div>

<h2 style="padding-left:10px;">Upgrade The Download Manager Plugin:</h2>

<table class="cm-upgrade-table"
       style="background:#fff; width: 100%; border:1px solid black; border-right:1px solid black; border-left:1px solid black;">
    <tr class="tr-head">
        <td style="text-align:center; font-size:20px; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0; width:28%">
            <strong>Features</strong></td>
        <td style="text-align:center; background-color:red; font-size:20px; color:white; width:18%">
            <strong>Current Edition</strong></td>
        <td style="text-align:center; background-color:green; font-size:20px; color:white; width:18%"><span class="dashicons dashicons-star-filled" style="color:yellow"></span> <strong>Pro</strong></td>
        <td style="text-align:center; background-color:blue; font-size:20px; color:white; width:18%"><span class="dashicons dashicons-awards" style="color:yellow"></span> <strong>Client Zone</strong></td>
        <td style="text-align:center; background-color:purple; font-size:20px; color:white; width:18%"><span class="dashicons dashicons-superhero-alt" style="color:yellow"></span> <strong>Ultimate</strong>
        </td>
    </tr>
    <tr>
        <td style="text-align:center; border-right: 1px solid #c0c0c0; width:28%"></td>
        <td style="text-align:center; font-size:20px; width:18%">FREE</td>
        <td style="text-align:center; font-size:20px; width:18%">$39</td>
        <td style="text-align:center; font-size:20px; width:18%">$69</td>
        <td style="text-align:center; font-size:20px; width:18%">$119</td>
    </tr>
    <tr>
        <td style="text-align:center; border-right: 1px solid #c0c0c0; width:28%"></td>
        <td style="text-align:center; font-size:16px; width:18%"></td>
        <td style="text-align:center; font-size:16px; width:18%">(For one Year / 1 Site)</td>
        <td style="text-align:center; font-size:16px; width:18%">(For one Year / 3 Sites)</td>
        <td style="text-align:center; font-size:16px; width:18%">(For one Year / 10 Sites)</td>
    </tr>
    <tr>
        <td style="text-align:center; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0; width:28%"></td>
        <td style="text-align:center; font-size:16px; border-bottom: 1px solid #c0c0c0; width:18%"></td>
        <td style="text-align:center; font-size:16px; border-bottom: 1px solid #c0c0c0; width:18%"><a href="https://www.cminds.com/wordpress-plugins-library/downloadsmanager/?utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" target="_blank">Details >></a>
        </td>
        <td style="text-align:center; font-size:16px; border-bottom: 1px solid #c0c0c0; width:18%"><a href="https://www.cminds.com/wordpress-plugins-library/downloadsmanager/?utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" target="_blank">Details >></a>
        </td>
        <td style="text-align:center; font-size:16px; border-bottom: 1px solid #c0c0c0; width:18%"><a href="https://www.cminds.com/wordpress-plugins-library/downloadsmanager/?utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" target="_blank">Details >></a>
        </td>
    </tr>
    <tr>
        <td style="text-align:center; border-right: 1px solid #c0c0c0; width:28%"></td>
        <td style="text-align:center; width:18%"></td>
        <td style="text-align:center; width:18%"><a href="https://www.cminds.com/?edd_action=add_to_cart&download_id=1930&edd_options[price_id]=1&utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" class="button button-primary" style="background-color:green;" title="Click to Buy PRO">Upgrade NOW >></a></td>
        <td style="text-align:center; width:18%"><a href="https://www.cminds.com/?edd_action=add_to_cart&download_id=51133&edd_options[price_id]=1&utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" class="button button-primary" style="background-color:blue;" title="Click to Buy CLIENT ZONE">Upgrade NOW >></a></td>
        <td style="text-align:center; width:18%"><a href="https://www.cminds.com/?edd_action=add_to_cart&download_id=87963&edd_options[price_id]=1&utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" class="button button-primary" style="background-color:purple;" title="Click to Buy ULTIMATE">Upgrade NOW >></a></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Unlimited Downloads
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Add unlimited number of downloads each having a dedicated page with description and additional information" dashicon="dashicons-editor-help."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Downloads Categories
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Assign each download to one or more categories. Browse downloads by categories."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Voting
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Vote for each downloads using a star rating system."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            View Download Count
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Automatically show the download count and number of views for each download page."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Support Forum
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Add a support forum to each download so user can ask question or add comments."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Internal Ajax Search
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Search the downloads using keywords."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            User Notifications
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Send custom email notifications to download authors when their file upload has been approved or support questions are posted. Notify users of file uploads to categories they follow. Notify the admin when uploads are pending approval."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            User Groups Permissions
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Add user to groups and set access restriction to categories or individual downloads by group."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Downloads can be Password Protected
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Support asking for a password before file can be downloaded."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Admin can define Upload Restriction
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Uploading files can be restricted to specific users or user groups."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Admin can define View Restrictions
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Viewing specific downloads or categories can be restricted to specific users or user group."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Shortcodes for downloads list
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Several shortcodes are supported. Shortcode can show most recent downloads, downloads with the highest download count and more."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Moderation Support
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="File uploaded by users can be moderated before posted."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            File Preview Option
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Support showing content with external viewer. Download including PDF / DOC / XLS files can be viewed with Google docs viewer."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Audio & Video Player Option
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Ability to show a video or audio player in the download page and to play a video / audio file before it is downloaded."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Customize Plugin Permalink
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Download URL can be set using a permalink in the plugin settings."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            User Profile with all Downloads
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Each user has a profile page showing all their uploads and basic information about the user."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Extended internal Search
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Use the internal search engine on your site to quickly search downloads and find files of interest."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Multiple index page view
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Download index page has multiple view options."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Log & Statistics
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Detailed reports and download statistics including who downloaded each file."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Second Level Navigation
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Support second level navigation in the category tree."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Download Shortcodes in Post/Pages
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Include in each post or page a download shortcode showing a single file download button with information about download."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Multiple File Upload
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Each download page can contain multiple files. File can be downloaded separately or using a zip to download all."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Automatic Zip Compression
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="When multiple files are uploaded user can download each file or all using a zip file. User can also choose the files they need and download them as a zip file."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Social Media Integration
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Ability to let users register, and login using their social media accounts."></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Multisite Support
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Works in WordPress multisite environment. Please check licensing information regarding Multisite support."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Customize labels
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Customize all plugin labels. This will ensure you can easily change messages and labels to adjust them to your language and terminology."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Restricted Customer Zone
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Allow your users to create a DropBox like solution in which users can upload files which they and  the admin can only see or send files directly to specific users."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Send and receive files from admin
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Admin can send files to specific users or group of users. User can upload files and send them to admin."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Widgets
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Several sidebar widgets can be added. Widget can show most recent downloads, downloads with the highest download count and more."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Disclaimer Support
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="A disclaimer can be shown before user is able to view downloads. User needs to approve disclaimer in order to view download."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Gravatar Support
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Show user gravatar in user list of downloads."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Customize Download Page
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Download page can be customized to remove or add components from it."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Integration with Store plugins
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Integration with external cart system such as EDD to show a shortcode instead of the download button."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Integration with Micropayments
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Integrates with CM MicroPayments plugin. This will support adding a transaction layer to each upload or download. For example, when a user downloads a file they then needs to pay X amount of virtual coins."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Payment Support
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Support paying with real money for downloading or uploading files. Payment system is based on Easy Digital Downloads cart system."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Registration support
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Support registration of users directly into groups defined by admin. Each group has permission to view files. Registration support includes login and registration shortcodes together with an invitation code system."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Anonymous Uploads
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Support anonymous uploads of files to the WordPress download manager."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Integration with PeepSo
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Integrates with PeepSo social networks. Let members upload files, create download links and share files between groups."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0;">
            Download visual widgets
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Add visual widgets to the download manager which you can add to your widgets and sidebar."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0; background-color:lightgreen;">
            One year of expert support
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="You receive 365 days of WordPress expert support. We will answer questions you have and also support any issue related to the plugin. We will also provide on-site support."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0; background-color:lightgreen;">
            Unlimited product updates
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="During the license period, you can update the plugin as many times as needed and receive any version release and security update."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0; background-color:lightgreen;">
            Plugin can be used forever
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Once license expires, If you choose not to renew the plugin license, you can still continue to use it as long as you want."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="width:28%; border-bottom: 1px solid #c0c0c0; border-right: 1px solid #c0c0c0; background-color:lightgreen;">
            Save 40% once renewing license
            <span class="dashicons dashicons-info-outline cminds-package-show-tooltip" style="color:green"
                  title="Once license expires, If you choose to renew the plugin license you can do this anytime you choose. The renewal cost will be 40% off the product cost."></span>
        </td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-no" style="color:red"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
        <td style="text-align:center; width:18%; border-bottom: 1px solid #c0c0c0; background-color:lightgreen;"><span class="dashicons dashicons-yes" style="color:green"></span></td>
    </tr>
    <tr>
        <td style="text-align:center; border-right: 1px solid #c0c0c0; width:28%"></td>
        <td style="text-align:center; font-size:20px; width:18%">FREE</td>
        <td style="text-align:center; font-size:20px; width:18%">$39</td>
        <td style="text-align:center; font-size:20px; width:18%">$69</td>
        <td style="text-align:center; font-size:20px; width:18%">$119</td>
    </tr>
    <tr>
        <td style="text-align:center; border-right: 1px solid #c0c0c0; width:28%"></td>
        <td style="text-align:center; width:18%"></td>
        <td style="text-align:center; width:18%"><a href="https://www.cminds.com/?edd_action=add_to_cart&download_id=1930&edd_options[price_id]=1&utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" class="button button-primary" style="background-color:green;" title="Click to Buy PRO">Upgrade NOW >></a></td>
        <td style="text-align:center; width:18%"><a href="https://www.cminds.com/?edd_action=add_to_cart&download_id=51133&edd_options[price_id]=1&utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" class="button button-primary" style="background-color:blue;" title="Click to Buy CLIENT ZONE">Upgrade NOW >></a></td>
        <td style="text-align:center; width:18%"><a href="https://www.cminds.com/?edd_action=add_to_cart&download_id=87963&edd_options[price_id]=1&utm_source=cmdmfree&utm_campaign=freeupgrade&upgrade=1" class="button button-primary" style="background-color:purple;" title="Click to Buy ULTIMATE">Upgrade NOW >></a></td>
    </tr>
</table>
