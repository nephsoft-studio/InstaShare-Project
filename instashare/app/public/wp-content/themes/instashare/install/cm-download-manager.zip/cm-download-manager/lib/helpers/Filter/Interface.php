<?php


interface CMDM_Filter_Interface {
    public function filter($value);
}

?>
