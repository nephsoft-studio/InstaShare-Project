		<!--   Core JS Files   -->
		<?php wp_footer(); ?>
		<!--   Core JS Files   -->
		<?php do_action( 'pzfm_after_footer_hook' ); ?>
	</body>
</html>
<?php do_action( 'pzfm_after_html_content_hook' ); ?>