<div class="container bg-white p-5">
	<div class="alert alert-danger text-center"><?php echo wp_kses_post( $error_message ); ?></div>
</div>