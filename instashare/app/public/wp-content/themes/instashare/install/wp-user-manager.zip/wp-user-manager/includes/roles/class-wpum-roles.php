<?php
/**
 * @package     wp-user-manager
 * @copyright   Copyright (c) 2020, WP User Manager
 * @license     https://opensource.org/licenses/GPL-3.0 GNU Public License
 */

/**
 * WPUM_Roles
 */
class WPUM_Roles extends WPUM_Collection {
	/**
	 * @var array
	 */
	public $counts = array();
}
