<?php
/**
 * The Template for the Account page header
 *
 * This template can be overridden by copying it to yourtheme/wpum/stripe/account/header.php
 *
 * @version 2.9.0
 */

?>

<h2><?php echo esc_html( $data->header ); ?></h2>
