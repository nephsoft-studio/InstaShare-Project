import { createHooks } from "@wordpress/hooks"

const hooks = createHooks()

export default hooks