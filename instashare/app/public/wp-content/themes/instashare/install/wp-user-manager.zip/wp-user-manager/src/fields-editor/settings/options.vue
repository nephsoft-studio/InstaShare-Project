<template>
	<div>
		input here
	</div>
</template>

<script>
export default {
	name: 'options'
}
</script>

