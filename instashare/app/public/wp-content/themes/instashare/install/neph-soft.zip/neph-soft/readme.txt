=== Neph Soft ===
Contributors: nephsoftstudio
Tags: homepage, companion, one click demo, sections, customizer, widget, settings
Requires PHP: 5.6

== Description ==

Neph Soft plugin to enhance the functionality of free themes made by <a href="https://www.instagram.com/nephsoftstudios/" rel="nofollow">Neph·Soft·Studio´s</a>. It provides intuitive features to your website. Make your demo replica within a minutes. Install any theme via single click install and import demo instantly. 

